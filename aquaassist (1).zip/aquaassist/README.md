# AquaAssist

Streamlit chatbot for NAWASA (National Water and Sewerage Authority, Grenada) customer service, powered by Gemini.

## Setup

```bash
pip install -r requirements.txt
```

## Before you deploy — required edits in `app.py`

1. **`NAWASA_WHATSAPP_NUMBER`** (near the top of `app.py`) — replace the placeholder with NAWASA's real WhatsApp number, digits only, international format (e.g. `14735551234`).
2. **`STAFF_PASSCODE`** — replace the placeholder, or better, set it as an environment variable / Streamlit secret so it isn't stored in code:
   ```bash
   export STAFF_PASSCODE="your-real-passcode"
   ```
   or in `.streamlit/secrets.toml`:
   ```toml
   STAFF_PASSCODE = "your-real-passcode"
   ```

## Run locally

```bash
streamlit run app.py
```

## Features

- Customer chat (Gemini-powered, replies in the customer's own language/dialect)
- Quick-action buttons (report leak, maintenance, billing, talk to a rep)
- "Report a Leak" form — saves structured reports to `data/reports.csv`
- Staff Portal (password gated) — staff can log in from the sidebar to view/download submitted reports
- WhatsApp button in the sidebar for direct contact

## Notes on data storage

Reports are currently saved to a local CSV file (`data/reports.csv`). This is fine for a demo/small pilot, but:
- It does **not** persist across deployments on most hosting platforms (e.g. Streamlit Community Cloud resets the filesystem on redeploy)
- It is **not** encrypted and has no access control beyond the app's passcode gate
- For production use with real customer data, move this to a proper database (e.g. Google Sheets via API, Supabase, or Postgres) — ask your developer to swap out `save_report()` / `load_reports()` in `app.py` for the database calls, the rest of the app doesn't need to change.
